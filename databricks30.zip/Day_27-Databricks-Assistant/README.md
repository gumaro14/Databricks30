Welcome to Day 27 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/) 

[Day 27: Databricks ASSISTANT | 30 Days of Databricks](https://youtu.be/XKKMXQWNeQs)