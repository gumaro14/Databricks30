Welcome to Day 23 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)   

[Day 23: Databricks Secrets | 30 Days of Databricks](https://youtu.be/x1mXZlllQmw)