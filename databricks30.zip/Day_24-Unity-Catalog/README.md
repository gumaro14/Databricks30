Welcome to Day 24 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)   

[Day 24: UNITY CATALOG ( FIRST LOOK) | 30 Days of Databricks](https://youtu.be/gtWmw6qPTb4)