Welcome to Day 9 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 9: Databricks Widgets in SQL Notebook | 30 Days of Databricks](https://youtu.be/DTPDpJMSllE)
