Welcome to Day 22 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)   

[Day 22: Databricks Workflows  | 30 Days of Databricks](https://youtu.be/lJrzgQfH1tc)