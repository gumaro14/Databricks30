Welcome to Day 13 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Day 13: How To Read CSV / Excel File In Databricks Notebook | 30 Days of Databricks
](https://youtu.be/ADcjHLaxiqA?si=OMI6FYveaWIM_Bnt)
