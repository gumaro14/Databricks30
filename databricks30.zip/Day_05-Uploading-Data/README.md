Welcome to Day 5 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 5: Uploading Data Into Databricks | 30 Days of Databricks](https://youtu.be/S09-bzyT0FA)
