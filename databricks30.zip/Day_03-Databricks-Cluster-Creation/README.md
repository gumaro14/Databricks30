Welcome to Day 3 of 30 Days of Databricks series.  

[Databricks website link](https://www.databricks.com/)  

[Databricks Cluster Creation](https://youtu.be/WxDD83DqT_U)