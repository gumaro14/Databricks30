Welcome to Day 8 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 8: Databricks Widgets in Python Notebook | 30 Days of Databricks](https://youtu.be/6cJskcBtlyc)
