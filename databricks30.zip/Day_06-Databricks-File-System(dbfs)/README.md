Welcome to Day 6 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 6: Databricks File System (dbfs) | 30 Days of Databricks](https://youtu.be/hJuvRQ94URQ?si=eOf9i__5CH-NC23F)
