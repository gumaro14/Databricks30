Welcome to Day 16 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 16: MLFlow Basics in Databricks Community Edition | 30 Days of Databricks](https://youtu.be/T811P_8dcSQ)