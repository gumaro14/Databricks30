Welcome to Day 28 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 29: Read Data From AWS S3 Bucket | 30 Days of Databricks](https://youtu.be/EUwywLCEVgU)