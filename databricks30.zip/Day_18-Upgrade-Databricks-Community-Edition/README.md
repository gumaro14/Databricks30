Welcome to Day 18 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 18: Upgrade From Databricks Community Edition to 14 days Free Trial | 30 Days of Databricks](https://youtu.be/4fVShsklkLw)