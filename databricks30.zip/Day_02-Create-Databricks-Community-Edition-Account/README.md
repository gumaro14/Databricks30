Welcome to Day 2 of 30 Days of Databricks series.  

[Databricks website link](https://www.databricks.com/)  

[Create Databricks Community Edition Account & UI Walkthrough](https://youtu.be/a8gsJG2lUP8?si=3eVG7-Z2vKmjYJUt)
