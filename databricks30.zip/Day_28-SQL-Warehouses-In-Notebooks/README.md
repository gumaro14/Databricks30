Welcome to Day 28 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/) 

[Day 28: SQL Warehouses In NOTEBOOKS | 30 Days of Databricks](https://youtu.be/9E69g6MuKwU)