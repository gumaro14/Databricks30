Welcome to Day 1 of 30 Days of Databricks series.  

[Databricks website link](https://www.databricks.com/)  

[Introduction To DATABRICKS | For Complete Beginners](https://youtu.be/_wJ_8E6VumU)