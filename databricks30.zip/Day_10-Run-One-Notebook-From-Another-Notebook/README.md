Welcome to Day 10 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Day 10: Run One Notebook from another notebook | 30 Days of Databricks](https://youtu.be/ZGCZFbEA6DY)
