Welcome to Day 4 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 4: How To Create Notebook In Databricks | 30 Days of Databricks](https://youtu.be/FksuyB-9TRk)