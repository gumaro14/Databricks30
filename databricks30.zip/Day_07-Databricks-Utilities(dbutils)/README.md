Welcome to Day 7 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Databricks - Day 7: Databricks Utilities (dbutils) | 30 Days of Databricks](https://youtu.be/456UanUbkhw?si=-yZjGbKwbJbaYGWs)
