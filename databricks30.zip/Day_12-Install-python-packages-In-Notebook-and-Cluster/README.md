Welcome to Day 12 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Day 12: How To Install Python Libraries In Databricks Notebook & Cluster| 30 Days of Databricks](https://youtu.be/JL5-DWMIWro)
