Welcome to Day 15 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 15: Common Delta Lake Operations in Databricks | 30 Days of Databricks](https://youtu.be/Dx_Y2iBqg6g)