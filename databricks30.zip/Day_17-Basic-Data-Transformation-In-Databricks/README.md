Welcome to Day 17 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 17: Basic DATA Transformation In DATABRICKS | 30 Days of Databricks](https://youtu.be/8tXrOQmNMWY)