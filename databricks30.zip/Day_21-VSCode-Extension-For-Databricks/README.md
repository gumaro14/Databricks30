Welcome to Day 21 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)   

[Day 21: Visual Studio Code Extension For DATABRICKS | 30 Days of Databricks](https://youtu.be/saQBIx_2lK4)
