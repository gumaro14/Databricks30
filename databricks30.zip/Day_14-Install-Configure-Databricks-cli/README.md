Welcome to Day 14 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)  

[Day 14: How To Install & Configure Databricks CLI | 30 Days of Databricks](https://youtu.be/CZ7x_OYmXys)
