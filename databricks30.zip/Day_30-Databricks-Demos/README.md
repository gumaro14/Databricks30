Welcome to Day 28 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)    

[Day 30: Databricks Demos | 30 Days of Databricks](https://youtu.be/fQblk9hsH-8)