Welcome to Day 11 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Day 11: Create dashboard from Databricks notebook | 30 Days of Databricks](https://youtu.be/uZtzARQ2bw8)
