Welcome to Day 19 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/) 

[Day 19: Create CLUSTER of YOUR Choice In Databricks Free Trial | 30 Days of Databricks](https://youtu.be/UUBzUMVw-hE)