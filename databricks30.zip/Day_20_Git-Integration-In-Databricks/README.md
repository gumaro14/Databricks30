Welcome to Day 20 of 30 days of Databricks series.

[Databricks website link](https://www.databricks.com/)

[Day 20: Git Integration In Databricks | 30 Days of Databricks](https://youtu.be/ffMV1DuU_ic)